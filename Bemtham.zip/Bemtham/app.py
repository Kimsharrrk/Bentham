from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS
from werkzeug.utils import secure_filename
from models import db, User, Clothing, Character
from PIL import Image
import os, uuid

app = Flask(__name__, instance_relative_config=True) #플라스크 앱 생성
CORS(app, resources={r"/api/*": {"origins": ["http://localhost:3000", "http://127.0.0.1:3000"]}})

os.makedirs(app.instance_path, exist_ok=True)
app.config["UPLOAD_FOLDER"] = "uploads"
os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

db_path = os.path.join(app.instance_path, "fashion.db")
app.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{db_path}"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db.init_app(app)
with app.app_context():
    db.create_all()

app.config["MAX_CONTENT_LENGTH"] = 16 * 1024 * 1024
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif"}

def allowed_file(filename: str) -> bool:
    # ★★★ 핵심 수정: .rsplit() 결과는 리스트이므로 [1]로 확장자를 선택 후 .lower() 호출
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route("/")
def home():
    return jsonify({"status": "ok", "message": "Fashion AI backend running"}), 200

@app.route("/uploads/<name>")
def download_file(name):
    return send_from_directory(app.config["UPLOAD_FOLDER"], name, as_attachment=False)

@app.route("/api/clothes", methods=["GET"])
def list_clothes():
    rows = Clothing.query.order_by(Clothing.created_at.desc()).all()
    return jsonify([{"id": r.id, "name": r.name, "category": r.category, "color": r.color, "image_url": f"/uploads/{r.image_path}"} for r in rows]), 200

@app.route("/api/clothes", methods=["POST"])
def upload_clothing():
    name = request.form.get("name") or "무명"
    category = request.form.get("category") or "기타"
    color = request.form.get("color")
    file = request.files.get("file")

    if not file or file.filename == "":
        return jsonify({"error": "file is required"}), 400
    if not allowed_file(file.filename):
        return jsonify({"error": "unsupported file type"}), 400

    base = secure_filename(file.filename)
    # ★★★ 핵심 수정: 여기서도 동일하게 [1]로 확장자를 선택 후 .lower() 호출
    ext = base.rsplit(".", 1)[1].lower()
    fname = f"{uuid.uuid4().hex}.{ext}"
    fpath = os.path.join(app.config["UPLOAD_FOLDER"], fname)
    file.save(fpath)

    thumb_name = None
    try:
        im = Image.open(fpath)
        im.thumbnail((512, 512))
        thumb_name = f"{uuid.uuid4().hex}_thumb.{ext}"
        im.save(os.path.join(app.config["UPLOAD_FOLDER"], thumb_name))
    except Exception:
        pass

    user = User.query.first()
    if not user:
        user = User(username="test_user", email="test@example.com")
        db.session.add(user); db.session.commit()

    item = Clothing(user_id=user.id, name=name, category=category, color=color, image_path=fname)
    db.session.add(item); db.session.commit()

    return jsonify({"id": item.id, "name": item.name, "category": category, "color": color, "image_url": f"/uploads/{fname}", "thumbnail_url": f"/uploads/{thumb_name}" if thumb_name else None}), 201

if __name__ == "__main__":
    app.run(debug=True, host="127.0.0.1", port=8000)
